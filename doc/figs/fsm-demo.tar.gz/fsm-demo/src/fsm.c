#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <inttypes.h>
/* make
* echo -ne "\x36\x36AAAA\x37\x13\xF7\xF7\xF7\xF7\x20\x04yolo00" | ./bin/fsm
echo -ne "\x36\x36AAAA\x37\x13\xF7\xF7\xF7\xF7\x20\x04\x01\x39\x58\x7d\x00" | ./bin/fsm
*/

#define MAX_LEN 64


typedef enum {
    STATE_0,
    STATE_1,
    STATE_2,
    STATE_CRASH,
} state_t;

typedef struct {
    state_t current;
} fsm_t;

typedef struct {
    uint16_t id;
    uint32_t data;
} msg_t;

static void fsm_run(fsm_t *fsm, msg_t *msg){
    uint32_t *nullptr = NULL;
    printf("Current state: %02d\n", fsm->current);
    switch (fsm->current) {
        case STATE_CRASH:
            printf("Crashing!\n");
	    	*(nullptr) = 0;
            break;
        case STATE_0:
            if (msg->id == 0x3636) {
                fsm->current = STATE_1;
                printf("Switching to state %02d\n", fsm->current);
                break;
            }
            goto reset;
        case STATE_1:
            if (msg->id == 0x1337){
                if (!((msg->data >> 16)^(msg->data & 0xF7F7)) ){
                    fsm->current = STATE_2;
                    printf("Switching to state %02d\n", fsm->current);
                    break;
                }
            }
            goto reset;
        case STATE_2:
            if ( (msg->id >> 4) == 0x42 ){
                msg->data ^= 0x12345678;
                if ( !( strncmp((char*)&msg->data, "yolo", 4))) {
                    fsm->current = STATE_CRASH;
                    printf("Switching to state %02d\n", fsm->current);
                    break;
                }
            }
            goto reset;
        default:
        reset:
            fsm->current = STATE_0;
            printf("Back to state: %02d\n", fsm->current);
            break;
    }
}

void parse_msg(msg_t *msg, uint8_t* buf, size_t len){
    if(len >= 2){
        msg->id = *(uint16_t*)(buf);
    } else {
        msg->id = 0xFFFF;
    }

    if (len >= 6){
        msg->data = *(uint32_t*)(buf+2);
    } else {
        msg->data = 0xFFFFFFFF;
    }
    return;
}

int main() {
    uint8_t buf[MAX_LEN];
    size_t nread;
    fsm_t fsm;
    msg_t msg;
    fsm.current = STATE_0;

    while(1){
        nread = read(0, buf, 6);
        if(nread <= 0)
            break;
        parse_msg(&msg, buf, nread);
        fsm_run(&fsm, &msg);
    }
}
